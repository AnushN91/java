/*Q1 ) Write a program to accept ‘n’ name of cities from the user and sort them in ascending order. [10 marks]*/

import java.util.Scanner;

public class Slip3_1

{

    public static void main(String[] args) 

    {

        Scanner s = new Scanner(System.in);

        System.out.print("Enter number of names you want to enter:");

        int n = s.nextInt();

        String names[] = new String[n];

        System.out.println("Enter all the names:");

        for(int i = 0; i < n; i++)

             names[i] = s.nextLine();

        for (int i = 0; i < n; i++) 

        {

            for (int j = i + 1; j < n; j++) 

            {

                if (names[i].compareTo(names[j])>0) 

                {

                    String temp = names[i];

                    names[i] = names[j];

                    names[j] = temp;

                }

            }

        }

        System.out.println("Names in Sorted Order:");

        for (int i = 0; i < n ; i++) 

                    System.out.println(names[i]);        
        
        s.close();
    }
    

}