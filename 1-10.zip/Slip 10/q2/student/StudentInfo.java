package student;

public class StudentInfo

{

  public void display_student(int r, String n, String c, double p)

  {

    System.out.println("Roll No. = " + r);

    System.out.println("Name = " + n);

    System.out.println("Class = " + c);

    System.out.println("Percentage = " + p + "%");

  }

}
