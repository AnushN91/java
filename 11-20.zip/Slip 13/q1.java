/*Q1) Write a program to accept a file name from command prompt, if the file exits then display number of words and lines in that file. [10 marks] */

import java.io.*;

class Slip13_1

{

    public static void main(String args[]) throws IOException

    {

        String line, dirname = args[0];

        int ch, i, cnt = 0, lcnt = 0;

        FileReader f1 = new FileReader(dirname);

        BufferedReader br = new BufferedReader(f1);

        while ((line = br.readLine()) != null)

        {

            lcnt++;

            String words[] = line.split("");

            cnt = cnt + words.length;

        }

        System.out.println("Total Number Of Lines:" + lcnt);

        System.out.println("Total Number Of Words:" + cnt);

    }

}