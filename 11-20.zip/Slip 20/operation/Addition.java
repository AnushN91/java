//Addition.java

package operation;

public class Addition

{

    public void add(int a, int b)

    {

        int c = a + b;

        System.out.println("Addition of 2 integer is :" + c);

    }

    public void sub(float a, float b)

    {

        float s = a - b;

        System.out.println("Substraction of 2 float values is :" + s);

    }

}