// Maximum.java

package operation;

public class Maximum

{

    public void max(int a, int b)

    {

        if (a > b)

            System.out.println(a + " is Maximum number of" + a + " and " + b);

        else

            System.out.println(b + " is Maximum number of" + a + " and " + b);

    }

}