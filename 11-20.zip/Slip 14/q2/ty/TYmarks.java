//TYmarks.java
package ty;

public class TYmarks

{

        public int Theory;

        public int Practicals;

        public TYmarks()

        {

                Theory = 0;

                Practicals = 0;

        }

        public TYmarks(int t, int p)

        {

                this.Theory = t;

                this.Practicals = p;

        }

}