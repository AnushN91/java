//SYmarks.java

package sy;

public class SYmarks

{

        public int ComputerTotal;

        public int MathsTotal;

        public int ElectronicsTotal;

        public SYmarks()

        {

                ComputerTotal = 0;

                MathsTotal = 0;

                ElectronicsTotal = 0;

        }

        public SYmarks(int c, int m, int e)

        {

                this.ComputerTotal = c;

                this.MathsTotal = m;

                this.ElectronicsTotal = e;

        }

}
