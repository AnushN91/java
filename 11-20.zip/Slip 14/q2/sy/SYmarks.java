//SYmarks.java

package  sy;

public class SYmarks

{

	 int computertotal;

	 int mathstotal;

	int electronicstotal;

	public SYmarks()

        {

                        computertotal=0;

			mathstotal=0;

			electronicstotal=0;

        }

        public SYmarks(int c,int m,int e)

        {

                this.computertotal=c;

                this.mathstotal=m;

                this.electronicstotal=e;

        }

}

	

