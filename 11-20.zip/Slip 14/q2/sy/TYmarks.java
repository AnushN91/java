//TYmarks.java
package ty;

public class TYmarks

{

	public int theory;

	public int practicals;

	public TYmarks()

        {

                theory=0;

		practicals=0;

        }

	public TYmarks(int t,int p)

        {

                this.theory=t;

                this.practicals=p;

        }

}