/*Q2) Write a Java program to create a Package “SY” which has a class SYMarks (members – ComputerTotal, MathsTotal, and ElectronicsTotal). Create another package TY which has a class TYMarks (members – Theory, Practicals). Create ‘n’ objects of Student class (having rollNumber, name, SYMarks and TYMarks). Add the marks of SY and TY computer subjects and calculate the Grade (‘A’ for >= 70, ‘B’ for >= 60 ‘C’ for >= 50, Pass Class for > =40 else‘FAIL’) and display the result of the student in proper format. [20 marks]*/

//main program

// Main Program: Student.java
import sy.SYmarks;
import ty.TYmarks;
import java.io.*;

public class Student {

    int roll_no;
    String name;
    SYmarks sym;
    TYmarks tym;
    String grade;

    public Student(int r, String na, int c_t, int m_t, int e_t, int t1, int p, String g) {
        roll_no = r;
        name = na;
        sym = new SYmarks(c_t, m_t, e_t);
        tym = new TYmarks(t1, p);
        grade = g;
    }

    // Display Roll No, Name, Marks, and Grade
    public void show() {
        System.out.println("Roll No: " + roll_no);
        System.out.println("Name: " + name);
        System.out.println("SY Computer marks: " + sym.ComputerTotal);
        System.out.println("SY Maths marks: " + sym.MathsTotal);
        System.out.println("SY Electronics marks: " + sym.ElectronicsTotal);
        System.out.println("TY Theory marks: " + tym.Theory);
        System.out.println("TY Practical marks: " + tym.Practicals);
        System.out.println("Grade: " + grade);
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter how many students");
        int n = Integer.parseInt(br.readLine());

        Student[] s = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Enter Roll No");
            int r = Integer.parseInt(br.readLine());

            System.out.println("Enter Name");
            String na = br.readLine();

            System.out.print("Enter SY Computer marks: ");
            int c_t = Integer.parseInt(br.readLine());

            System.out.print("Enter SY Maths marks: ");
            int m_t = Integer.parseInt(br.readLine());

            System.out.print("Enter SY Electronics marks: ");
            int e_t = Integer.parseInt(br.readLine());

            System.out.print("Enter TY Theory marks: ");
            int t1 = Integer.parseInt(br.readLine());

            System.out.print("Enter TY Practical marks: ");
            int p = Integer.parseInt(br.readLine());

            // Calculate total computer marks from SY and TY
            int totalComputerMarks = (c_t + t1 + p) / 3;

            // Calculate the grade
            String g;
            if (totalComputerMarks >= 70) {
                g = "A";
            } else if (totalComputerMarks >= 60) {
                g = "B";
            } else if (totalComputerMarks >= 50) {
                g = "C";
            } else if (totalComputerMarks >= 40) {
                g = "Pass";
            } else {
                g = "Fail";
            }

            // Create a student object
            s[i] = new Student(r, na, c_t, m_t, e_t, t1, p, g);

            // Display the student details
            s[i].show();
        }
    }
}
