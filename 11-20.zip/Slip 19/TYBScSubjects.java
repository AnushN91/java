//Q2) Write a program which shows the combo box which includes list of T.Y.B.Sc.(Comp. Sci) subjects. Display the selected subject in a text field.
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TYBScSubjects extends JFrame {
    
    // Constructor
    public TYBScSubjects() {
        // Set title for the JFrame
        setTitle("T.Y.B.Sc (Comp. Sci) Subjects");
        setSize(400, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        
        // Array of subjects for the combo box
        String[] subjects = { 
            "Operating Systems", 
            "Data Structures", 
            "Database Management Systems", 
            "Computer Networks", 
            "Software Engineering",
            "Web Programming",
            "Machine Learning",
            "Artificial Intelligence"
        };
        
        // Create JComboBox and JTextField
        JComboBox<String> subjectComboBox = new JComboBox<>(subjects);
        JTextField selectedSubjectField = new JTextField(20);
        selectedSubjectField.setEditable(false); // Set the text field to non-editable
        
        // Add ActionListener to JComboBox
        subjectComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected item and set it to the text field
                String selectedSubject = (String) subjectComboBox.getSelectedItem();
                selectedSubjectField.setText(selectedSubject);
            }
        });
        
        // Add components to JFrame
        add(new JLabel("Select Subject: "));
        add(subjectComboBox);
        add(new JLabel("Selected Subject: "));
        add(selectedSubjectField);
    }

    // Main method to run the program
    public static void main(String[] args) {
        // Create instance of the JFrame
        TYBScSubjects frame = new TYBScSubjects();
        // Make the frame visible
        frame.setVisible(true);
    }
}
